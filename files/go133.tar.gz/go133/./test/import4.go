// errorcheckdir

// Copyright 2009 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Verify that various kinds of "imported and not used"
// errors are caught by the compiler.
// Does not compile.

package ignored
