package main

import "./p2"

func main() {
	_ = p2.SockUnix()
}
