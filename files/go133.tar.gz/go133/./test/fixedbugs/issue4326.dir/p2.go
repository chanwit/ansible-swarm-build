package p2

import "./p1"

func NewO() p1.O { return nil }
