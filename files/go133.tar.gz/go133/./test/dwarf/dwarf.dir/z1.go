

//line x1.go:4
package main
func F1() {}
