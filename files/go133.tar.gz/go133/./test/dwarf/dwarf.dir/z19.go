
//line x19.go:4
package main
func F19() {}
