
//line x8.go:4
package main
func F8() {}
