
//line x7.go:4
package main
func F7() {}
